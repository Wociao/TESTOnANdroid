#pragma once
void WriteTOCSV();
void WriteToCSV(double *Result, int NO);

