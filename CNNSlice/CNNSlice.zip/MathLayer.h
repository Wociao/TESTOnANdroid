#pragma once
double ExpSumToProb(double * Orig, double *NewO, int dem, double *Prob);
double ExpSumToProbToLoss(double * Orig, double *NewO, int dem, double *Prob, double *Loss, int GroundT);