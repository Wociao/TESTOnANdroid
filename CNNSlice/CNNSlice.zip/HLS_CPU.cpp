#include <stdio.h>
#include "FileIO.h"
#include "CNNLayer.h"
#include "MathLayer.h"
//#include "Network.h"
#include "AddingNoise.h"
#include "FileIOCSV.h"


#define BATSIZE 32

/*��һ���ֶ���������ṹ*/
/*=========================================
NetWorkNode:����ڵ㣬Bָ����bias

OutputNode: �����֮��softmax�����

LossNode���������loss value

NetWorkWeight������֮��ڵ�Ȩ��
=========================================*/

struct NetWorkNode
{

	double Seond1[200];
	double Thired[50];
	double Fourth[10];
	double Seond1B[200];
	double ThiredB[50];
	double FourthB[10];
} NNode;

struct OutputNode
{

	double Exp[10];
	double SumofExp;
	double Prob[10];
	double Loss[10];

} ONode;

struct BackNode
{

	double Db4[10];
	double Db3[50];
	double Db2[200];
	double Seond1[200];
	double Thired[50];
	double Fourth[10];
	double DSeond1[200 * 784];
	double DThired[50 * 200];
	double DFourth[10 * 50];

} BNode;

struct NetWorkbatch
{
	double Seond1Bat[BATSIZE][200 * 784];
	double ThiredBat[BATSIZE][50 * 200];
	double FourthBat[BATSIZE][10 * 50];
	double Seond1BBat[BATSIZE][200];
	double ThiredBBat[BATSIZE][50];
	double FourthBBat[BATSIZE][10];
} NBat;

struct NetWorkWeight
{
	double Seond1[200 * 784];
	double Thired[50 * 200];
	double Fourth[10 * 50];
} NWeight;

/*============================Start====================================
Protection:
1.random
2.adding noise
==============================Start===============================*/
/*
struct NetWorkWeightR
{
	double Seond1[200 * 784];
	double Thired[50 * 200];
	double Fourth[10 * 50];
} NWeightR;
struct NetWorkNodeR
{
	double Seond1[200];
	double Thired[50];
	double Fourth[10];
	double Seond1B[200];
	double ThiredB[50];
	double FourthB[10];
} NNodeR;*/
//=============================end====================================


//=====================================================================
/*��һ���ֶ���������ṹ*/
/*
=============+++++++++++++++
2.307179448830937 [0.10098569 0.11170167 0.09640025 0.10333706 0.09606873 0.09076936
 0.09954162 0.10587555 0.09583138 0.0994887 ] 6
=============+++++++++++++++
*/
int findMax(double prob[10], int dem)
{
	int i = 0;
	int k = 0;
	double TMP = 0;
	for (i = 0; i < dem; i++)
	{
		if (TMP < prob[i])
		{
			TMP = prob[i];
			k = i;
		}
	}
	return k;
}

int DigitNumber(int index)
{
	int Len = 1;
	double tmp = double(index);
	//while (double(double(tmp) / 10.0 )> 1)
	while (tmp / 10.0 >= 1)
	{
		tmp = tmp / 10;
		Len++;
	}
	return Len;
}
void CopyFilename(char *filenameB, char *filenameO)
{
	int i = 25;
	int j = 0;
	for (j = 0; j < i; j++)
	{
		filenameB[j] = filenameO[j];
	}
}
void nameMaker(char *filenameB, int Index)
{
	int i = 0;
	int len = 25;
	int startPoint = 18;
	int insertPoint = 13;
	int digitLen = DigitNumber(Index);
	int tmp;
	int Remain = Index;
	//ƽ�� digitLen-1 ���ַ� ��һ����Ϊԭ������һ������index
	//printf("=====%s====\n", filenameB);
	for (i = 0; i < startPoint - insertPoint; i++)
	{
		filenameB[startPoint - i + digitLen - 1] = filenameB[startPoint - i];
		//printf("=====%s====\n", filenameB);
	}
	//�޸���������
	for (i = digitLen; i > 0; i--)
	{
		tmp = Remain % 10;
		filenameB[insertPoint + i - 1] = '0' + tmp;
		Remain = int(Remain / 10);
		//filenameB[startPoint - i] = filenameB[startPoint - i - 1];
		//printf("+++%s++++\n", filenameB);
	}
	//filenameB[insertPoint] = 'C';
}


void nameMakerT(char *filenameB, int Index)
{
	int i = 0;
	int len = 25;
	int startPoint = 17;
	int insertPoint = 12;
	int digitLen = DigitNumber(Index);
	int tmp;
	int Remain = Index;
	//ƽ�� digitLen-1 ���ַ� ��һ����Ϊԭ������һ������index
	//printf("=====%s====\n", filenameB);
	for (i = 0; i < startPoint - insertPoint; i++)
	{
		filenameB[startPoint - i + digitLen - 1] = filenameB[startPoint - i];
		//printf("=====%s====\n", filenameB);
	}
	//�޸���������
	for (i = digitLen; i > 0; i--)
	{
		tmp = Remain % 10;
		filenameB[insertPoint + i - 1] = '0' + tmp;
		Remain = int(Remain / 10);
		//filenameB[startPoint - i] = filenameB[startPoint - i - 1];
		//printf("+++%s++++\n", filenameB);
	}
	//filenameB[insertPoint] = 'C';
}

void initNode()
{
	int i;
	for (i = 0; i < 200; i++)
	{
		//NNode.Seond1[i] = 0.1;
		NNode.Seond1[i] = 0.0;
	}
	for (i = 0; i < 50; i++)
	{

		NNode.Thired[i] = 0.0;
	}
	for (i = 0; i < 10; i++)
	{
		NNode.Fourth[i] = 0.0;
	}

}



void initBNode()
{
	int i;
	for (i = 0; i < 200; i++)
	{
		//NNode.Seond1[i] = 0.1;
		BNode.Seond1[i] = 0.0;
	}
	for (i = 0; i < 50; i++)
	{

		BNode.Thired[i] = 0.0;
	}
	for (i = 0; i < 10; i++)
	{
		BNode.Fourth[i] = 0.0;
	}

}

void init()
{
	int i;
	for (i = 0; i < 200; i++)
	{
		//NNode.Seond1[i] = 0.1;
		NNode.Seond1B[i] = 0.1;
	}
	for (i = 0; i < 50; i++)
	{

		NNode.ThiredB[i] = 0.1;
	}
	for (i = 0; i < 10; i++)
	{
		NNode.FourthB[i] = 0.1;
	}

	for (i = 0; i < 200 * 784; i++)
	{
		//NNode.Seond1[i] = 0.1;
		NWeight.Seond1[i] = 0.00001;
	}
	for (i = 0; i < 200 * 50; i++)
	{
		//NNode.Seond1[i] = 0.1;
		NWeight.Thired[i] = 0.00001;
	}
	for (i = 0; i < 10 * 50; i++)
	{
		//NNode.Seond1[i] = 0.1;
		NWeight.Fourth[i] = 0.00001;
	}

}

void initB()
{
	int i;
	int j;
	for (j = 0; j < BATSIZE; j++)
	{
		for (i = 0; i < 200; i++)
		{
			//NNode.Seond1[i] = 0.1;
			NBat.Seond1BBat[j][i] = 0.0;
		}
		for (i = 0; i < 50; i++)
		{

			NBat.ThiredBBat[j][i] = 0.0;
		}
		for (i = 0; i < 10; i++)
		{
			NBat.FourthBBat[j][i] = 0.0;
		}

		for (i = 0; i < 200 * 784; i++)
		{
			//NNode.Seond1[i] = 0.1;
			NBat.Seond1Bat[j][i] = 0.0;
		}
		for (i = 0; i < 200 * 50; i++)
		{
			//NNode.Seond1[i] = 0.1;
			NBat.ThiredBat[j][i] = 0.0;
		}
		for (i = 0; i < 10 * 50; i++)
		{
			//NNode.Seond1[i] = 0.1;
			NBat.FourthBat[j][i] = 0.0;
		}
	}


}


void BatchSum()
{
	int i;
	int j;


	double tmp;
	double norm = 1;
	for (i = 0; i < 200; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.Seond1BBat[j][i] + tmp;
		}
		//NNode.Seond1[i] = 0.1;
		NNode.Seond1B[i] = tmp / norm;
	}
	for (i = 0; i < 50; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.ThiredBBat[j][i] + tmp;
		}
		NNode.ThiredB[i] = tmp / norm;
	}
	for (i = 0; i < 10; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.FourthBBat[j][i] + tmp;
		}
		NNode.FourthB[i] = tmp / norm;
	}

	for (i = 0; i < 200 * 784; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.Seond1Bat[j][i] + tmp;
		}
		//NNode.Seond1[i] = 0.1;
		NWeight.Seond1[i] = tmp / norm;
	}
	for (i = 0; i < 200 * 50; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.ThiredBat[j][i] + tmp;
		}
		//NNode.Seond1[i] = 0.1;
		NWeight.Thired[i] = tmp / norm;
	}
	for (i = 0; i < 10 * 50; i++)
	{
		tmp = 0;
		for (j = 0; j < BATSIZE; j++)
		{
			tmp = NBat.FourthBat[j][i] + tmp;
		}
		//NNode.Seond1[i] = 0.1;
		NWeight.Fourth[i] = tmp / norm;
	}



}

void mainF()
{
	printf("OK");
	while (1)
	{
		;
	}
}


/*��һ�棬���Խ���������ʶ����д���ֵĴ���*/
/*V1*/
void mainV1()
{
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);

	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("==========reordering and noise===\n");

	while (1)
	{
		;
	}
}



/*���� fault injection*/
/* V2 ���μ��ɹ�*/

void mainV2()
{
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("==========adding noise===\n");

	int NumbOfNoise = 100;
	int AddingType = 0;   //0 randomly, 1->important first
	int Welen = 200 * 784;
	AddingNoise(NWeight.Seond1, NumbOfNoise, AddingType, Welen);
	//NWeight.Fourth;
	Welen = 10*50;
	AddingNoise(NWeight.Fourth, NumbOfNoise, AddingType, Welen);

	printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);

	
	while (1)
	{
		;
	}
}






void mainK()
{
	//��ȡģ��Ȩ���ļ�
	//  ��һ������CPU�ˣ���ȡȨ���ļ�
	printf("Test using existing weight!\n");
	
	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);

	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);



	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("==========reordering and noise===\n");
	while (1)
	{
		;
	}
	//return 0;

	//=============================end====================================

	//================evaluate the FPGA part=======================================

	double Weight[784 * 200 + 200 * 50];
	double Bias[200 + 50];

	for (i = 0; i < 784 * 200;i++)
	{
		Weight[i] = NWeight.Seond1[i];
	}
	for (i = 0; i < 50 * 200; i++)
	{
		Weight[i+ 784 * 200] = NWeight.Thired[i];
	}

	for (i = 0; i <  200; i++)
	{
		Bias[i] = NNode.Seond1B[i];
	}
	for (i = 0; i < 50; i++)
	{
		Bias[i + 200] = NNode.ThiredB[i];
	}



	/*
	�Ŀɣ�
	�ϲ��ְ�����CPU���ֶ�LENET�Ĳ��ԣ�Ȼ���ʼ����Ȩ��buff��Weight����ƫ��buff ��Bias��
	��ӦFPGA ip�ڲ� InputDataW �� InputBais
	����һ����Ҫ�ȳ�ʼ��һ�£� flagΪ1 ��ʼ��Ȩ�غ�ƫ�á�TODO NO1.
	Ȼ�����һ��forѭ�����������в���ͼƬ��
	��forѭ���У��Ȼ�ȡ��Ƶ��Ȼ��flag=2����ͼƬ�� TODO NO2 InputDataM ��ӦimageB
	������� FPGA��IP����������Ľ���������Ȩ����������������� TODO NO3

	*/

	//============= flagΪ1 ��ʼ��Ȩ�غ�ƫ��=================NO1===Start=======

	//============= flagΪ1 ��ʼ��Ȩ�غ�ƫ��=================NO1===END=======

	AccCount = 0;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);

		//============= flag=2����ͼƬ=================NO2===Start=======
		// imageB ���൱�� FPGA IP���� InputDataM

		//============= flag=2����ͼƬ=================NO2===END=======

		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		//ע�͵�ǰ�������FPGA��
		//FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		//FClayerForwardRelu(NNode.Seond1, 200);
		//FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		//FClayerForwardRelu(NNode.Thired, 50);

		//============= ������� FPGA��IP=================NO3===Start=======
		
		
		
		// OutputData ��ֵ���浽 NNode.Thired ����Ϊ50
		//�����һ��50��forѭ����������

		//============= ������� FPGA��IP=================NO3===END=======

		//��ɺ����һ���ڱ�����ɼ��㡣
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);




	printf("=====%d", count);
	while (1)
	{
		;
	}
}





/* V3, fault injection with multiple test and collect the result*/

double FunctionAddNoise(int NO, int Type, int layA, int layB, int layC, int numberA, int numberB, int numberC)
{
	/*
		NO: �ܲ��Դ���
		Type: 0:������ӣ� 1 ����Ҫ������
		layA,layB,layC ����������ڵ����ӵı�־
		numberA,B,C ������Ŀ��
	*/
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("\n");
	printf("======%d====adding noise==%d=======\n",NO, numberA);
	printf("\n");
	int NumbOfNoise = 100;
	int AddingType = Type;   //0 randomly, 1->important first
	int Welen = 200 * 784;
	if (layA)
	{
		AddingNoise(NWeight.Seond1, numberA, AddingType, Welen);
	}
	if (layB)
	{
		Welen = 200 * 50;
		AddingNoise(NWeight.Thired, numberB, AddingType, Welen);
	}
	if (layC)
	{
		Welen = 10 * 50;
		AddingNoise(NWeight.Fourth, numberC, AddingType, Welen);
	}
	//NWeight.Fourth;
	
	

	printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);
	return Acc;

}

/* V4, fault injection with multiple test and collect the result*/

double FunctionAddNoiseAndDefence(int NO, int Type, int layA, int layB, int layC, int numberA, int numberB, int numberC, int DefLeng)
{
	/*
		NO: �ܲ��Դ���
		Type: 0:������ӣ� 1 ����Ҫ������
		layA,layB,layC ����������ڵ����ӵı�־
		numberA,B,C ������Ŀ��
	*/
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("\n");
	printf("======%d====adding noise==%d=======\n", NO, numberA);
	printf("\n");
	int NumbOfNoise = 100;
	int AddingType = Type;   //0 randomly, 1->important first
	int Welen = 200 * 784;
	if (layA)
	{
		AddingNoiseDef(NWeight.Seond1, numberA, AddingType, Welen, DefLeng);
	}
	if (layB)
	{
		Welen = 200 * 50;
		AddingNoiseDef(NWeight.Thired, numberB, AddingType, Welen, DefLeng);
	}
	if (layC)
	{
		Welen = 10 * 50;
		AddingNoiseDef(NWeight.Fourth, numberC, AddingType, Welen, DefLeng);
	}
	//NWeight.Fourth;



	printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);
	return Acc;

}

//���������ռ�һ����

void mainV7()

{
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	int TotSizeLayer[3] = { 784 * 200, 200 * 50, 50 * 10 };
	int PortionA[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionB[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionDef[9] = { 1,2,3,4,5,6,7,8,9 };
	int TestDefPort = 5;
	double Result[1000];
	double TMPres = 0;
	int NO = 0;
	int layA; 
	int layB; 
	int layC;
	//������
/*
	//WriteTOCSV();
	double Test[10] = { 1,2,3,4,5,6,7,8,9,0 };
	AddingNoise(Test, 5, 1, 10);
	for (int i = 0; i < 10; i++)
	{
		printf("==%f==,", Test[i]);
	}
	
	while (1)
	{
		;
	}
	
	*/

	for (int i = 0; i < 3; i++)
	{
		if (i == 0)
		{
			layA = 1;
			layB = 0;
			layC = 0;
		}
		if (i == 1)
		{
			layA = 0;
			layB = 1;
			layC = 0;
		}
		if (i == 2)
		{
			layA = 0;
			layB = 0;
			layC = 1;
		}
		//ֻ������
		/*
		for (int j = 0; j < 9; j++)
		{
			int number = int( TotSizeLayer[i] * PortionA[j] / 10);
			TMPres = FunctionAddNoise(NO, 0, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}
		for (int j = 0; j <9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			TMPres = FunctionAddNoise(NO, 1, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}
*/
		//ֻ����
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionA[j] / 10);
			int numberB = int(TotSizeLayer[i] * PortionA[j] / 10 * TestDefPort/10);
			TMPres = FunctionAddNoiseAndDefence(NO, 0, layA, layB, layC, number, number, number, numberB);
			Result[NO] = TMPres;
			NO++;
		}
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			int numberB = int(TotSizeLayer[i] * PortionB[j] / 100 * TestDefPort / 10);
			TMPres = FunctionAddNoiseAndDefence(NO, 1, layA, layB, layC, number, number, number, numberB);
			Result[NO] = TMPres;
			NO++;
		}
	}
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	WriteToCSV(Result,NO);
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n"); printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	
}




void mainV6()
{
	int TotSizeLayer[3] = { 784 * 200, 200 * 50, 50 * 10 };
	int PortionA[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionB[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionDef[9] = { 1,2,3,4,5,6,7,8,9 };
	int TestDefPort = 0;
	int T = 0;
	double ResultAt[200];
	double ResultDef[2000];
	double TMPres = 0;
	int NO = 0;
	int layA;
	int layB;
	int layC;
	//������
/*
	//WriteTOCSV();
	double Test[10] = { 1,2,3,4,5,6,7,8,9,0 };
	AddingNoise(Test, 5, 1, 10);
	for (int i = 0; i < 10; i++)
	{
		printf("==%f==,", Test[i]);
	}

	while (1)
	{
		;
	}

	*/

	for (int i = 0; i < 3; i++)
	{
		if (i == 0)
		{
			layA = 1;
			layB = 0;
			layC = 0;
		}
		if (i == 1)
		{
			layA = 0;
			layB = 1;
			layC = 0;
		}
		if (i == 2)
		{
			layA = 0;
			layB = 0;
			layC = 1;
		}
		//ֻ������
		/*
		for (int j = 0; j < 9; j++)
		{
			int number = int( TotSizeLayer[i] * PortionA[j] / 10);
			TMPres = FunctionAddNoise(NO, 0, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}
		for (int j = 0; j <9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			TMPres = FunctionAddNoise(NO, 1, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}*/

		//ֻ����
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionA[j] / 10);
			for (T = 0; T < 9; T++)
			{
				int numberB = int(TotSizeLayer[i] * PortionA[j] / 10 * (T+1) / 10);
				TMPres = FunctionAddNoiseAndDefence(NO, 0, layA, layB, layC, number, number, number, numberB);
				ResultDef[NO] = TMPres;
				NO++;
			}
			for (T = 0; T < 9; T++)
			{
				int numberB = int(TotSizeLayer[i] * PortionA[j] / 100 * (T + 1) / 10);
				TMPres = FunctionAddNoiseAndDefence(NO, 0, layA, layB, layC, number, number, number, numberB);
				ResultDef[NO] = TMPres;
				NO++;
			}
		}
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			for (T = 0; T < 9; T++)
			{
				int numberB = int(TotSizeLayer[i] * PortionB[j] / 100 * (T + 1) / 10);
				TMPres = FunctionAddNoiseAndDefence(NO, 1, layA, layB, layC, number, number, number, numberB);
				ResultDef[NO] = TMPres;
				NO++;
			}
		}
	}
	WriteToCSV(ResultDef, NO);
	//WriteToCSVB(Result, NO);

}



/* V2, fault injection with multiple test and collect the result
Using our method for defence.
*/

double FunctionAddNoiseAndDefenceV2(int NO, int Type, int layA, int layB, int layC, int numberA, int numberB, int numberC, int DefLeng,int ProLen)
{
	/*
		NO: �ܲ��Դ���
		Type: 0:������ӣ� 1 ����Ҫ������
		layA,layB,layC ����������ڵ����ӵı�־
		numberA,B,C ������Ŀ��
	*/
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("\n");
	printf("======%d====adding noise==%d=======\n", NO, numberA);
	printf("\n");
	int NumbOfNoise = 100;
	int AddingType = Type;   //0 randomly, 1->important first
	int Welen = 200 ;
	if (layA)
	{
		Welen = 200* ProLen/10;
		AddingNoiseOurDef(NWeight.Seond1, numberA, AddingType, 784,200, Welen, DefLeng);
		//WriteToCSV(NWeight.Seond1, 784*200);
		//return 0;
	}
	if (layB)
	{
		Welen =  50 * ProLen / 10;
		AddingNoiseOurDef(NWeight.Thired, numberB, AddingType, 200, 50, Welen, DefLeng);
	}
	if (layC)
	{
		Welen = 10 * ProLen / 10;
		AddingNoiseOurDef(NWeight.Fourth, numberC, AddingType, 50,10, Welen,  DefLeng);
	}
	//NWeight.Fourth;



	printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);
	return Acc;

}


/*
mainV8: ʵ���˻������ܣ�����ÿ�β���ֻ���ÿһ��
*/

void main()

{
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	int TotSizeLayer[3] = { 784 * 200, 200 * 50, 50 * 10 };
	int PortionA[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionB[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionDef[9] = { 1,2,3,4,5,6,7,8,9 };
	int TestDefPort = 5;
	double Result[1000];
	double TMPres = 0;
	int Prolen =2;
	int NO = 0;
	int layA;
	int layB;
	int layC;
	//������
/*
	//WriteTOCSV();
	double Test[10] = { 1,2,3,4,5,6,7,8,9,0 };
	AddingNoise(Test, 5, 1, 10);
	for (int i = 0; i < 10; i++)
	{
		printf("==%f==,", Test[i]);
	}

	while (1)
	{
		;
	}

	*/

	for (int i = 0; i < 3; i++)
	{
		if (i == 0)
		{
			layA = 1;
			layB = 0;
			layC = 0;
		}
		if (i == 1)
		{
			layA = 0;
			layB = 1;
			layC = 0;
			//Prolen = Prolen + 1;
		}
		if (i == 2)
		{
			layA = 0;
			layB = 0;
			layC = 1;
			Prolen = Prolen + 4;
		}
		//ֻ������
		/*
		for (int j = 0; j < 9; j++)
		{
			int number = int( TotSizeLayer[i] * PortionA[j] / 10);
			TMPres = FunctionAddNoise(NO, 0, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}
		for (int j = 0; j <9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			TMPres = FunctionAddNoise(NO, 1, layA, layB, layC, number, number, number);
			Result[NO] = TMPres;
			NO++;
		}
*/
//ֻ����
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionA[j] / 10);
			int numberB = int(TotSizeLayer[i] * PortionA[j] / 10 * TestDefPort / 10);
			printf(" >>>>>>>>>>>>>>>>>>>>>>>>checking numbers %d     ====    %d\n", number, numberB);
			TMPres = FunctionAddNoiseAndDefenceV2(NO, 0, layA, layB, layC, number, number, number, numberB, Prolen);
			Result[NO] = TMPres;
			NO++;
		}
		for (int j = 0; j < 9; j++)
		{
			int number = int(TotSizeLayer[i] * PortionB[j] / 100);
			int numberB = int(TotSizeLayer[i] * PortionB[j] / 100 * TestDefPort / 10);
			TMPres = FunctionAddNoiseAndDefenceV2(NO, 1, layA, layB, layC, number, number, number, numberB, Prolen);
			Result[NO] = TMPres;
			NO++;
		}
	}
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	WriteToCSV(Result, NO);
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n"); printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");

}





/* V3, All fault injection on 3 layers with multiple test and collect the result
Using our method for defence.
*/

double FunctionAddNoiseAndDefenceV3(int NO, int Type, int layA, int layB, int layC, int numberA, int numberB, int numberC, int DefLeng, int ProLen)
{
	/*
		NO: �ܲ��Դ���
		Type: 0:������ӣ� 1 ����Ҫ������
		layA,layB,layC ����������ڵ����ӵı�־
		numberA,B,C ������Ŀ��
	*/
	printf("Test using existing weight!\n");

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);


	/*============================Start====================================
	Protection:
	1.random
	2.adding noise
	==============================Start===============================*/
	printf("\n");
	printf("======%d====adding noise==%d=======\n", NO, numberA);
	printf("\n");
	int NumbOfNoise = 100;
	int AddingType = Type;   //0 randomly, 1->important first
	int Welen = 200;
	if (layA)
	{
		Welen = 200 * ProLen / 10;
		AddingNoiseOurDef(NWeight.Seond1, numberA, AddingType, 784, 200, Welen, DefLeng);
	}
	if (layB)
	{
		Welen = 50 * ProLen / 10;
		AddingNoiseOurDef(NWeight.Thired, numberB, AddingType, 200, 50, Welen, DefLeng);
	}
	if (layC)
	{
		//Welen = 10 * (ProLen+4) / 10;
		Welen = 10 * (ProLen + 4) / 10;
		AddingNoiseOurDef(NWeight.Fourth, numberC, AddingType, 50, 10, Welen, DefLeng);
	}
	//NWeight.Fourth;



	printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}
		*/
		//==========forward propagation================
		initNode();
		FClayerForward(imageB, NNode.Seond1, NWeight.Seond1, 784, 200, NNode.Seond1B);
		FClayerForwardRelu(NNode.Seond1, 200);
		FClayerForward(NNode.Seond1, NNode.Thired, NWeight.Thired, 200, 50, NNode.ThiredB);
		FClayerForwardRelu(NNode.Thired, 50);
		FClayerForward(NNode.Thired, NNode.Fourth, NWeight.Fourth, 50, 10, NNode.FourthB);
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		Pre_Res = findMax(NNode.Fourth, 10);
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);
	return Acc;

}


/*Final_Before I add FPGA*/
void mainV9()

{
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	int TotSizeLayer[3] = { 784 * 200, 200 * 50, 50 * 10 };
	int PortionA[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionB[9] = { 1,2,3,4,5,6,7,8,9 };
	int PortionDef[9] = { 1,2,3,4,5,6,7,8,9 };
	int TestDefPort = 5;
	double Result[1000];
	double TMPres = 0;
	int Prolen = 3;
	int NO = 0;
	int layA;
	int layB;
	int layC;
	//������
/*
	//WriteTOCSV();
	double Test[10] = { 1,2,3,4,5,6,7,8,9,0 };
	AddingNoise(Test, 5, 1, 10);
	for (int i = 0; i < 10; i++)
	{
		printf("==%f==,", Test[i]);
	}

	while (1)
	{
		;
	}

	*/

		
	layA = 1;
	layB = 1;
	layC = 1;
		
	//ֻ������
	/*
	for (int j = 0; j < 9; j++)
	{
		int number = int( TotSizeLayer[i] * PortionA[j] / 10);
		TMPres = FunctionAddNoise(NO, 0, layA, layB, layC, number, number, number);
		Result[NO] = TMPres;
		NO++;
	}
	for (int j = 0; j <9; j++)
	{
		int number = int(TotSizeLayer[i] * PortionB[j] / 100);
		TMPres = FunctionAddNoise(NO, 1, layA, layB, layC, number, number, number);
		Result[NO] = TMPres;
		NO++;
	}*/
	/*
	for (int j = 0; j < 9; j++)
	{
		int numbera = int(TotSizeLayer[0] * PortionA[j] / 10);
		int numberb = int(TotSizeLayer[1] * PortionA[j] / 10);
		int numberc = int(TotSizeLayer[2] * PortionA[j] / 10);
		int numberB = TestDefPort;
		TMPres = FunctionAddNoise(NO, 0, layA, layB, layC, numbera, numberb, numberc);
		Result[NO] = TMPres;
		NO++;
	}
	for (int j = 0; j < 9; j++)
	{
		int numbera = int(TotSizeLayer[0] * PortionA[j] / 100);
		int numberb = int(TotSizeLayer[1] * PortionA[j] / 100);
		int numberc = int(TotSizeLayer[2] * PortionA[j] / 100);
		int numberB = TestDefPort;
		TMPres = FunctionAddNoise(NO, 1, layA, layB, layC, numbera, numberb, numberc);
		Result[NO] = TMPres;
		NO++;
	}
*/

//ֻ����
	for (int j = 0; j < 9; j++)
	{
		int numbera = int(TotSizeLayer[0] * PortionA[j] / 10);
		int numberb = int(TotSizeLayer[1] * PortionA[j] / 10);
		int numberc = int(TotSizeLayer[2] * PortionA[j] / 10);
		int numberB = TestDefPort;
		TMPres = FunctionAddNoiseAndDefenceV3(NO, 0, layA, layB, layC, numbera, numberb, numberc, numberB, Prolen);
		Result[NO] = TMPres;
		NO++;
	}
	for (int j = 0; j < 9; j++)
	{
		int numbera = int(TotSizeLayer[0] * PortionA[j] / 100);
		int numberb = int(TotSizeLayer[1] * PortionA[j] / 100);
		int numberc = int(TotSizeLayer[2] * PortionA[j] / 100);
		int numberB = TestDefPort;
		TMPres = FunctionAddNoiseAndDefenceV3(NO, 1, layA, layB, layC, numbera, numberb, numberc, numberB, Prolen);
		Result[NO] = TMPres;
		NO++;
	}
	
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");
	WriteToCSV(Result, NO);
	printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n"); printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\ \n");

}




/* ==========================================================================================================
	last task: check the recognition accuracy in the two protection methods.


*/



//====================================================================================modify weight =================================================== 8

/*new weight for fixed portion checking================================================================*/
//weight
int DemANF = 260;
int DemBNF = 185;
int DemCNF = 44;
double Seond1WNF[260 * 784];
double ThiredWNF[185 * 260];
double FourthWNF[44 * 185];
//node
double Seond1NF[260];
double ThiredNF[185];
double FourthNF[44];
//bias
double Seond1BNF[260];
double ThiredBNF[185];
double FourthBNF[44];

void ModifyWeightFix(int *Pair1, int *Pair2, int *Pair3)
{
	int i = 0;
	int j = 0;
	//weight 1
	for (j = 0; j < 784; j++)
	{
		for (i = 0; i < 260; i++)
		{
			if (i < 200)
			{
				Seond1WNF[j * 260 + i] = NWeight.Seond1[j * 200 + i];
			}
			else
			{
				Seond1WNF[j * 260 + i] = NWeight.Seond1[j * 200 + Pair1[i - 200]];
			}

		}
	}
	//weight 2
	for (j = 0; j < 260; j++)
	{
		if (j < 200)
		{
			for (i = 0; i < 185; i++)
			{
				if (i < 50)
				{
					ThiredWNF[j * 185 + i] = NWeight.Thired[j * 50 + i];
				}
				else
				{
					if (i < 60)
					{
						ThiredWNF[j * 185 + i] = NWeight.Thired[j * 50 + Pair2[i - 50]];
					}
					else
					{
						ThiredWNF[j * 185 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 185; i++)
			{
				ThiredWNF[j * 185 + i] = 0;
			}
		}

	}
	//weight 3
	for (j = 0; j < 185; j++)
	{
		if (j < 50)
		{
			for (i = 0; i < 44; i++)
			{
				if (i < 10)
				{
					FourthWNF[j * 44 + i] = NWeight.Fourth[j * 10 + i];
				}
				else
				{
					if (i < 13)
					{
						FourthWNF[j * 44 + i] = NWeight.Fourth[j * 10 + Pair3[i - 10]];
					}
					else
					{
						FourthWNF[j * 44 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 44; i++)
			{
				FourthWNF[j * 44 + i] = 0;
			}
		}

	}
	for (j = 0; j < 260; j++)
	{
		Seond1NF[j] = 0.0;
		if (j < 200)
		{
			Seond1BNF[j] = NNode.Seond1B[j];
		}
		else
		{
			Seond1BNF[j] = 0;
		}
	}
	for (j = 0; j < 185; j++)
	{
		ThiredNF[j] = 0.0;
		if (j < 50)
		{
			ThiredBNF[j] = NNode.ThiredB[j];
		}
		else
		{
			ThiredBNF[j] = 0;
		}
	}
	for (j = 0; j < 44; j++)
	{
		FourthNF[j] = 0.0;
		if (j < 10)
		{
			FourthBNF[j] = NNode.FourthB[j];
		}
		else
		{
			FourthBNF[j] = 0;
		}
	}
}



/*new weight for dynamic portion checking==============================================================================*/
int DemAND = 240;
int DemBND = 140;
int DemCND = 37;
//weight
double Seond1WND[240 * 784];
double ThiredWND[140 * 240];
double FourthWND[37 * 140];
//node
double Seond1ND[240];
double ThiredND[140];
double FourthND[37];
//bias
double Seond1BND[240];
double ThiredBND[140];
double FourthBND[37];

void ModifyWeightDyn(int *Pair1, int *Pair2, int *Pair3)
{
	int i = 0;
	int j = 0;
	//weight 1
	for (j = 0; j < 784; j++)
	{
		for (i = 0; i < 240; i++)
		{
			if (i < 200)
			{
				Seond1WND[j * 240 + i] = NWeight.Seond1[j * 200 + i];
			}
			else
			{
				Seond1WND[j * 240 + i] = NWeight.Seond1[j * 200 + Pair1[i - 200]];
			}

		}
	}
	//weight 2
	for (j = 0; j < 240; j++)
	{
		if (j < 200)
		{
			for (i = 0; i < 140; i++)
			{
				if (i < 50)
				{
					ThiredWND[j * 140 + i] = NWeight.Thired[j * 50 + i];
				}
				else
				{
					if (i < 80)
					{
						ThiredWND[j * 140 + i] = NWeight.Thired[j * 50 + Pair2[i - 50]];
					}
					else
					{
						ThiredWND[j * 140 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 140; i++)
			{
				ThiredWND[j * 140 + i] = 0;
			}
		}

	}
	//weight 3
	for (j = 0; j < 140; j++)
	{
		if (j < 50)
		{
			for (i = 0; i < 37; i++)
			{
				if (i < 10)
				{
					FourthWND[j * 37 + i] = NWeight.Fourth[j * 10 + i];
				}
				else
				{
					if (i < 16)
					{
						FourthWND[j * 37 + i] = NWeight.Fourth[j * 10 + Pair3[i - 10]];
					}
					else
					{
						FourthWND[j * 37 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 37; i++)
			{
				FourthWND[j * 37 + i] = 0;
			}
		}

	}
	for (j = 0; j < 240; j++)
	{
		Seond1ND[j] = 0.0;
		if (j < 200)
		{
			Seond1BND[j] = NNode.Seond1B[j];
		}
		else
		{
			Seond1BND[j] = 0;
		}
	}
	for (j = 0; j < 140; j++)
	{
		ThiredND[j] = 0.0;
		if (j < 50)
		{
			ThiredBND[j] = NNode.ThiredB[j];
		}
		else
		{
			ThiredBND[j] = 0;
		}
	}
	for (j = 0; j < 37; j++)
	{
		FourthND[j] = 0.0;
		if (j < 10)
		{
			FourthBND[j] = NNode.FourthB[j];
		}
		else
		{
			FourthBND[j] = 0;
		}
	}

}

void ModifyWeightFixB(int *Pair1, int *Pair2, int *Pair3)
{
	int i = 0;
	int j = 0;
	//weight 1
	for (j = 0; j < 784; j++)
	{
		for (i = 0; i < 240; i++)
		{
			if (i < 200)
			{
				Seond1WND[j * 240 + i] = NWeight.Seond1[j * 200 + i];
			}
			else
			{
				Seond1WND[j * 240 + i] = NWeight.Seond1[j * 200 + Pair1[i - 200]];
			}

		}
	}
	//weight 2
	for (j = 0; j < 240; j++)
	{
		if (j < 200)
		{
			for (i = 0; i < 140; i++)
			{
				if (i < 50)
				{
					ThiredWND[j * 140 + i] = NWeight.Thired[j * 50 + i];
				}
				else
				{
					if (i < 80)
					{
						ThiredWND[j * 140 + i] = NWeight.Thired[j * 50 + Pair2[i - 50]];
					}
					else
					{
						ThiredWND[j * 140 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 140; i++)
			{
				ThiredWND[j * 140 + i] = 0;
			}
		}

	}
	//weight 3
	for (j = 0; j < 140; j++)
	{
		if (j < 50)
		{
			for (i = 0; i < 37; i++)
			{
				if (i < 10)
				{
					FourthWND[j * 37 + i] = NWeight.Fourth[j * 10 + i];
				}
				else
				{
					if (i < 16)
					{
						FourthWND[j * 37 + i] = NWeight.Fourth[j * 10 + Pair3[i - 10]];
					}
					else
					{
						FourthWND[j * 37 + i] = 1;
					}

				}

			}
		}
		else
		{
			for (i = 0; i < 37; i++)
			{
				FourthWND[j * 37 + i] = 0;
			}
		}

	}
	for (j = 0; j < 240; j++)
	{
		Seond1ND[j] = 0.0;
		if (j < 200)
		{
			Seond1BND[j] = NNode.Seond1B[j];
		}
		else
		{
			Seond1BND[j] = 0;
		}
	}
	for (j = 0; j < 140; j++)
	{
		ThiredND[j] = 0.0;
		if (j < 50)
		{
			ThiredBND[j] = NNode.ThiredB[j];
		}
		else
		{
			ThiredBND[j] = 0;
		}
	}
	for (j = 0; j < 37; j++)
	{
		FourthND[j] = 0.0;
		if (j < 10)
		{
			FourthBND[j] = NNode.FourthB[j];
		}
		else
		{
			FourthBND[j] = 0;
		}
	}
}


void initNodeK()
{
	int j = 0;
	for (j = 0; j < 240; j++)
	{
		Seond1ND[j] = 0.0;

	}
	for (j = 0; j < 140; j++)
	{
		ThiredND[j] = 0.0;

	}
	for (j = 0; j < 37; j++)
	{
		FourthND[j] = 0.0;

	}
	for (j = 0; j < 260; j++)
	{
		Seond1NF[j] = 0.0;

	}
	for (j = 0; j < 185; j++)
	{
		ThiredNF[j] = 0.0;

	}
	for (j = 0; j < 44; j++)
	{
		FourthNF[j] = 0.0;
	}
}
//====================================================================================modify weight end===================================================8


double FunctionCheckPerformance(int demA ,int demB, int demC)
{
	/*
		demA.b.c ����ά�ȡ�
	*/
	printf("Test using modified weight!\n");
	
	//printf("==========adding noise  done===\n");
	//=========================׼��ѵ��ͼƬ�Ͳ���ͼƬ��label==================
	char filenameTrainLabel[25] = "TrainingLabel.txt";
	char filenameTeestLabeel[25] = "TestingLabel.txt";
	int TrainLabel[60000];
	int TestLabel[10000];
	TReadImageMNistLabel(filenameTrainLabel, TrainLabel);
	TReadImageMNistLabel(filenameTeestLabeel, TestLabel);

	//=================׼��ѵ��ͼƬ�Ͳ���ͼƬ=================
	double imageB[784] = { 0 };
	//ReadImage(filename);
	//image=ReadImageMNist(filename);
	char filenameO[25] = "TrainingImage0.txt";
	char filenameB[25] = "TrainingImage0.txt";
	char filenameOT[25] = "TestingImage0.txt";
	char filenameBT[25] = "TestingImage0.txt";
	int countImages = 60000;
	int testImages = 10000;
	int countImageIndex = 1;

	int Pre_Res;
	int T;
	int kID;
	int AccCount = 0;
	int i, j;
	for (countImageIndex = 0; countImageIndex < testImages; countImageIndex++)
	{
		CopyFilename(filenameBT, filenameOT);
		nameMakerT(filenameBT, countImageIndex);
		//printf("obtain the file of: %s     \n", filenameB);
		TReadImageMNistC(filenameBT, imageB);
		/*
		for (kID = 0; kID < 784; kID++)
		{
			//printf("%d     %f\n", kID, imageB[kID]);
			printf("%d     %f\n", kID, NWeight.Seond1[kID]);

		}

		double Seond1WNF[260 * 784];
double ThiredWNF[185 * 260];
double FourthWNF[44 * 185];
//node
double Seond1NF[260];
double ThiredNF[185];
double FourthNF[44];
//bias
double Seond1BNF[260];
double ThiredBNF[185];
double FourthBNF[44];

		*/
		//==========forward propagation================
		if (demA == 260)
		{
			initNodeK();
			FClayerForward(imageB, Seond1NF, Seond1WNF, 784, demA, Seond1BNF);
			FClayerForwardRelu(Seond1NF, demA);
			FClayerForward(Seond1NF, ThiredNF, ThiredWNF, demA, demB, ThiredBNF);
			FClayerForwardRelu(ThiredNF, demB);
			FClayerForward(ThiredNF, FourthNF, FourthWNF, demB, demC, FourthBNF);
		}
		else
		{
			initNodeK();
			FClayerForward(imageB, Seond1ND, Seond1WND, 784, demA, Seond1BND);
			FClayerForwardRelu(Seond1ND, demA);
			FClayerForward(Seond1ND, ThiredND, ThiredWND, demA, demB, ThiredBND);
			FClayerForwardRelu(ThiredND, demB);
			FClayerForward(ThiredND, FourthND, FourthWND, demB, demC, FourthBND);
		}
		
		//==========calculate the loss deviation================
		//ONode.SumofExp = ExpSumToProb(NNode.Fourth, ONode.Exp , 10, ONode.Prob);
		if (demA == 260)
		{
			Pre_Res = findMax(FourthNF, 10);
		}
		else
		{
			Pre_Res = findMax(FourthND, 10);
		}
		T = TestLabel[countImageIndex];//��ȡgroundtruth

		if (Pre_Res == T)
		{
			AccCount++;
			//printf("=====%d   ---------%d\n", Pre_Res, T);
		}


	}
	double Acc = double(double(AccCount) / double(testImages));
	printf("The recognition accuracy on CPU is %f\n", Acc);
	return Acc;

}


void mainV10()
{
	int Parir1[100];
	int Parir2[100];
	int Parir3[100];
	int i = 0;
	for (i = 0; i < 100; i++)
	{
		Parir1[i] = i;
		Parir2[i] = i;
		Parir3[i] = i;
	}


	//read original weight

	char WeightWA[25] = "001_WA_F.csv";
	char WeightWB[25] = "001_WB_F.csv";
	char WeightWC[25] = "001_WC_F.csv";
	char WeightBAC[25] = "001_BA_F.csv";
	char WeightBBC[25] = "001_BB_F.csv";
	char WeightBCC[25] = "001_BC_F.csv";
	int count = 0;
	count = ReadWeightAndBiasFromFiles(WeightWA, NWeight.Seond1, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWB, NWeight.Thired, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightWC, NWeight.Fourth, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBAC, NNode.Seond1B, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBBC, NNode.ThiredB, 784, 200);
	count = ReadWeightAndBiasFromFiles(WeightBCC, NNode.FourthB, 784, 200);
	double Result = 0;
	int DemA = 260;
	int DemB = 185;
	int DemC = 44;
	ModifyWeightFix(Parir1, Parir2, Parir3);
	Result=FunctionCheckPerformance(DemA, DemB, DemC);
	printf("the result is %f \n", Result);
	DemA = 240;
	DemB = 140;
	DemC = 37;
	ModifyWeightDyn(Parir1, Parir2, Parir3);
	//ModifyWeightFixB(Parir1, Parir2, Parir3);
	Result = FunctionCheckPerformance(DemA, DemB, DemC);
	printf("the result is %f \n", Result);
	while (1)
	{
		;
	}
}
