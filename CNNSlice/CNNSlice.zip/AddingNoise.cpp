/*adding noise*/



#include <cmath>
#include <iostream>
#include <cstdlib>// Header file needed to use rand
using namespace std;

#define MAXLEN 160000


double buff[MAXLEN];
int buffInd[MAXLEN];

double buffP[MAXLEN];
int buffIndP[MAXLEN];

int bufTMP[800];
int bufTMPF[800];

int bufTMPT[800];
int bufTMPTind[800];

int IsInTheArray(int Ind, int lenDef)
{
	int i = 0;
	int Flag = 0;	//0 ��ʾû�д���
	for (i = 0; i < lenDef; i++)
	{
		if (Ind == buffIndP[i])
			return  1;
	}
	return Flag;

}


int IsInTheArrayB(int Ind, int lenDef)
{
	int i = 0;
	int Flag = 0;	//0 ��ʾû�д���
	for (i = 0; i < lenDef; i++)
	{
		if (Ind == bufTMPTind[i])
			return  1;
	}
	return Flag;

}


/*Max 200 MAXLEN */
int AddingNoise(double * buf, int number, int type, int TotLen)
{
	

	int i = 0;
	int j = 0;
	int k = 0;
	int indexNU = 0;

	for (int i = 0; i < MAXLEN; i++)
	{
		buff[i]=0;
		buffInd[i]=0;
	}

	if (type == 0)
	{
		for (i = 0; i < number; i++)
		{
			indexNU=rand() % TotLen;
			//buf[indexNU] = 0;
			buf[indexNU] = buf[indexNU]*-2;
		}
	}
	else
	{
		if (number > MAXLEN)
		{
			number = MAXLEN;
		}
		
		for (i = 0; i < MAXLEN; i++)
		{
			buff[i] = 0;
		}
		double min=0;
		int minInd = 0;
		//int minInd = 0;
		for (i = 0; i < TotLen; i++)
		{
			//Ŀ��ֵ����
			if (fabs(buf[i]) > min)
			{
				buff[minInd] = buf[i];
				buffInd[minInd] = i;
				//go through the buf and update with the target 
				min = 1000;
				for (k = 0; k < number; k++)
				{
							
					if (buff[k] < min)
					{
						min = buff[k];
						minInd = k;
					}
								
				}
				//break;
					
				
			}
		}
		for (k = 0; k < number; k++)
		{
			//buf[buffInd[k]] = 0;	
			buf[buffInd[k]] = buf[buffInd[k]]*-1;
			//printf("==%d==,", buffInd[k]);
		}
		printf("\n");
	}
	return 0;
}



/*Max 200 MAXLEN */
int AddingNoiseDef(double * buf, int number, int type, int TotLen, int DefLen)
{


	int i = 0;
	int j = 0;
	int k = 0;
	int indexNU = 0;

	for (int i = 0; i < MAXLEN; i++)
	{
		buff[i] = 0;
		buffInd[i] = 0;
		buffP[i] = 0;
		buffP[i] = 0;
	}

	//�ҳ�Ҫ�����Ľڵ�
	double min = 0;
	int minInd = 0;
	for (i = 0; i < TotLen; i++)
	{
		//Ŀ��ֵ����
		if (fabs(buf[i]) > min)
		{
			buffP[minInd] = buf[i];
			buffIndP[minInd] = i;
			//go through the buf and update with the target 
			min = 1000;
			for (k = 0; k < DefLen; k++)
			{

				if (buffP[k] < min)
				{
					min = buffP[k];
					minInd = k;
				}

			}
			//break;


		}
	}

	//�����

	if (type == 0)	//�����
	{
		for (i = 0; i < number; i++)
		{
			indexNU = rand() % TotLen;
			while (IsInTheArray(indexNU, DefLen))
			{
				indexNU = rand() % TotLen;
			}
			//buf[indexNU] = 0;
			buf[indexNU] = buf[indexNU] * -1;
		}
	}
	else      //����Ҫ�ļ�
	{
		if (number > MAXLEN)
		{
			number = MAXLEN;
		}

		for (i = 0; i < MAXLEN; i++)
		{
			buff[i] = 0;
		}
		
		//int minInd = 0;
		min = 0;
		minInd = 0;
		for (i = 0; i < TotLen; i++)
		{
			//Ŀ��ֵ����
			if (fabs(buf[i]) > min)
			{
				buff[minInd] = buf[i];
				buffInd[minInd] = i;
				//go through the buf and update with the target 
				min = 1000;
				for (k = 0; k < number; k++)
				{

					if (buff[k] < min)
					{
						min = buff[k];
						minInd = k;
					}

				}
				//break;


			}
		}
		for (k = 0; k < number; k++)
		{
			//buf[buffInd[k]] = 0;	
			if (IsInTheArray(buffInd[k], DefLen))
				continue;
			buf[buffInd[k]] = buf[buffInd[k]] * -1;
			//printf("==%d==,", buffInd[k]);
		}
		printf("\n");
	}
	return 0;
}





/*Max 200 MAXLEN */
int AddingNoiseOurDef(double * buf, int number, int type, int demA, int demB, int ProLen, int DefLen)
{
	/*demA -> previous layer*/
	int TotLen = demA * demB;
	int i = 0;
	int j = 0;
	int k = 0;
	int indexNU = 0;
	int ind = 0;

	for (int i = 0; i < MAXLEN; i++)
	{
		buff[i] = 0;
		buffInd[i] = 0;
		buffP[i] = 0;
		buffP[i] = 0;
	}

	//�ҳ�Ҫ�����Ľڵ�
	// 1. �Ȱѷ���Ҫ�������Ȩֵ�ҳ�����index����buffIndP
	double min = 0;
	int minInd = 0;
	for (i = 0; i < TotLen; i++)
	{
		//Ŀ��ֵ����
		if (fabs(buf[i]) > min)
		{
			buffP[minInd] = buf[i];
			buffIndP[minInd] = i;
			//go through the buf and update with the target 
			min = 1000;
			for (k = 0; k < number; k++)
			{

				if (buffP[k] < min)
				{
					min = buffP[k];
					minInd = k;
				}

			}
			//break;


		}
	}
	// 2. ��������Ҫ���Ȩֵ�ֲ���Ƶ������bufTMP
	for (i = 0; i < demB; i++)
	{
		bufTMP[i] = 0;
		bufTMPT[i] = 0;
		bufTMPTind[i] = 0;
	}
	
	for (i = 0; i < number; i++)
	{
		ind= int(buffIndP[i] % demB);
		bufTMP[ind] = bufTMP[ind] + 1;
	}
	// 3. ����Ƶ���ߵ�ǰK�������б���������K���ֲ�ȷ��index �� bufTMPF bufTMPTind
	min = 0;
	minInd = 0;
	for (i = 0; i < demB; i++)
	{
		//Ŀ��ֵ����
		if (bufTMP[i] > min)
		{
			bufTMPT[minInd] = bufTMP[i];
			bufTMPTind[minInd] = i;
			//go through the buf and update with the target 
			min = 65530;
			for (k = 0; k < ProLen; k++)
			{

				if (bufTMPT[k] < min)
				{
					min = bufTMPT[k];
					minInd = k;
				}

			}
			//break;


		}
	}
	printf("-------------Protected ind-------------\n");
	for (k = 0; k < ProLen; k++)
	{
		printf(" %d ,", bufTMPTind[k]);

	}
	printf("\n");
	printf("--------------------end---total %d----------------\n", ProLen);


	//�����

	if (type == 0)	//�����
	{
		for (i = 0; i < number; i++)
		{
			indexNU = rand() % TotLen;
			ind = indexNU % demB;
			//while (IsInTheArrayB(ind, ProLen))
			//{
			//	indexNU = rand() % TotLen;
			//}
			if (IsInTheArrayB(ind, ProLen))
				continue;
			//buf[indexNU] = 0;
			buf[indexNU] = buf[indexNU] * -1;
		}
	}
	else      //����Ҫ�ļ�
	{
		if (number > MAXLEN)
		{
			number = MAXLEN;
		}

		for (i = 0; i < MAXLEN; i++)
		{
			buff[i] = 0;
		}

		//int minInd = 0;
		min = 0;
		minInd = 0;
		for (i = 0; i < TotLen; i++)
		{
			//Ŀ��ֵ����
			if (fabs(buf[i]) > min)
			{
				buff[minInd] = buf[i];
				buffInd[minInd] = i;
				//go through the buf and update with the target 
				min = 1000;
				for (k = 0; k < number; k++)
				{

					if (buff[k] < min)
					{
						min = buff[k];
						minInd = k;
					}

				}
				//break;


			}
		}
		for (k = 0; k < number; k++)
		{
			//buf[buffInd[k]] = 0;	
			ind = buffInd[k] % demB;
			//while (IsInTheArrayB(ind, ProLen))
			if (IsInTheArrayB(ind, ProLen))
				continue;
			buf[buffInd[k]] = buf[buffInd[k]] * -1;
			//printf("==%d==,", buffInd[k]);
		}
		printf("\n");
	}
	return 0;
}