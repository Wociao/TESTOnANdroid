#pragma once
int AddingNoise(double * buf, int number, int type, int TotLen);
int AddingNoiseDef(double * buf, int number, int type, int TotLen, int DefLen);
int IsInTheArray(int Ind, int lenDef);
int AddingNoiseOurDef(double * buf, int number, int type, int demA, int demB, int ProLen, int DefLen);