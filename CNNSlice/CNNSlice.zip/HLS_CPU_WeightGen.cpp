#include <stdio.h>
#include "FileIO.h"
#include "CNNLayer.h"
#include "MathLayer.h"
//#include "Network.h"
#include "AddingNoise.h"
#include "FileIOCSV.h"


void mainTT()
{
	printf("helloword");
	while (1)
	{
		;
	}
}